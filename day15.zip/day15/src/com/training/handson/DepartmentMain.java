package com.training.handson;


import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class DepartmentMain {
Department objdept;
ObjectOutputStream oout;
ObjectInputStream oin;

Scanner sc;
Employee objemp;
DepartmentMain() throws IOException{
sc=new Scanner(System.in);
objdept=new Department();
FileInputStream f1=new FileInputStream("/home/administrator/java/hello.txt");
FileOutputStream f2=new FileOutputStream("/home/administrator/java/hello.txt",true);
oout=new ObjectOutputStream(f2);
oin=new ObjectInputStream(f1);
}
public void writeAccept() throws IOException {
	System.out.println("depatmt name");
	objdept.setDeptname(sc.next());
	System.out.println("enter dept id");
	objdept.setDeptid(sc.nextInt());
	System.out.println("enter hpwmany employee you want to store");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Employee e=new Employee();
		System.out.println("enter emp name");
		e.setEmpname(sc.next());
		System.out.println("enter emo  id");
		e.setEmpid(sc.nextInt());
		objdept.setEmp(e);
	}
	oout.writeObject(objdept);
	oout.flush();
}
public void readData() {

	try {
		while(oin.available()>0)
		//objdept=(Department) oin.readObject();
			
		System.out.println("department name is"+objdept.getDeptname());
		System.out.println("department id is:"+objdept.getDeptid());
		System.out.println("emp name:"+objdept.getEmp().getEmpname());
		System.out.println("employee name"+objdept.getEmp().getEmpname());
		System.out.println("employee id"+objdept.getEmp().getEmpid());
	//} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public static void main(String args[]) {
	try {
		DepartmentMain ob=new DepartmentMain();
		ob.writeAccept();
	ob.readData();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
