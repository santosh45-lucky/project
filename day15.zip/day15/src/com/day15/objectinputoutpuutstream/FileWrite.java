package com.day15.objectinputoutpuutstream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;
public class FileWrite {
Scanner sc;
FileOutputStream fout;
ObjectOutputStream oout;
FileWrite() {
	sc=new Scanner(System.in);
	try {
		fout=new FileOutputStream("/home/administrator/java/hello.txt");
		oout=new ObjectOutputStream(fout);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(IOException e) {
	e.printStackTrace();	
	}
}
public void writeData() {
	System.out.println("enter howmany data you want to enter");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
	Product p=new Product();
	System.out.println("enter pid");
	p.setPid(sc.nextInt());
	System.out.println("enter pname");
	p.setPname(sc.next());
	
	System.out.println("enter price");
	p.setPrice(sc.nextDouble());
	
	System.out.println("enter total sale");
	p.setTotalsale(sc.nextDouble());
	try {
		oout.writeObject(p);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
}
