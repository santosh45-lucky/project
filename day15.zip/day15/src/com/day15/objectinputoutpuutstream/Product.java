package com.day15.objectinputoutpuutstream;

import java.io.Serializable;

public class Product implements Serializable{
	private int pid;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalsale() {
		return totalsale;
	}
	public void setTotalsale(double totalsale) {
		this.totalsale = totalsale;
	}
	private String pname;
	private double price;
	private int quantity;
	private transient double totalsale;

}
