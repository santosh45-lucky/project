package com.day15.objectinputoutpuutstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


public class FileRead {
	FileInputStream fin;
	ObjectInputStream  objin;
FileRead(){
	try {
		fin=new FileInputStream("/home/administrator/java/hello.txt");
		objin=new ObjectInputStream(fin);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(IOException e) {
		e.printStackTrace();
	}
	
}
public void readData() {
	Product p1;
	try {
		while(fin.available()>0) {
		p1 = (Product)objin.readObject();

		System.out.println("pid is:"+p1.getPid());
		System.out.println("pname is"+p1.getPname());
		System.out.println("total sale"+p1.getTotalsale());
	} 
	}catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

public static void main(String args[]) {
	FileWrite wob=new FileWrite();
	wob.writeData();
	FileRead robb=new FileRead();
	robb.readData();
}
}
