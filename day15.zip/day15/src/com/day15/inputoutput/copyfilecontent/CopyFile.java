package com.day15.inputoutput.copyfilecontent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyFile {
	FileWriter fw;
	FileReader fr;
	CopyFile(){
		try {
			 fw=new FileWriter("/home/administrator/java/copydemo.txt",true);
			 fr=new FileReader("/home/administrator/java/welcome.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void copydata() {
		  int i;
		     try {
				while((i = fr.read())!= -1) {  
					 fw.write((char)i);
					 fw.flush();
				 
				 }
				System.out.println("data copied");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
public static void main(String args[]) {
	CopyFile ob=new CopyFile();
	ob.copydata();
}
}
