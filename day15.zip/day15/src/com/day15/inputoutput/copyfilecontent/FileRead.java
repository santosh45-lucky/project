package com.day15.inputoutput.copyfilecontent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;



public class FileRead {
	FileInputStream fin;
		
FileRead(){
	try {
		fin=new FileInputStream("/home/administrator/java/copydemo.txt");

	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(IOException e) {
		e.printStackTrace();
	}
	
}
public void readData() {

	try {
		
		
		if(fin.available()==0) {
			System.out.println("no datat aviavle you have to enter data");
			
		}else {
		byte data[]=new byte[fin.available()];
		fin.read(data);
	for(int i=0;i<data.length;i++) {
		System.out.print((char)data[i]);
	}
		}
}catch(FileNotFoundException e) {
	System.out.println(e.getMessage());
}catch(IOException ee) {
	
}
}public static void main(String args[]) {
	FileWrite wob=new FileWrite();
	wob.writeData();
	FileRead robb=new FileRead();
	robb.readData();
	
}
}

