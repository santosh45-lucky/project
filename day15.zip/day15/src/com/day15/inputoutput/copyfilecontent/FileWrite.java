package com.day15.inputoutput.copyfilecontent;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;
public class FileWrite {
Scanner sc;
FileOutputStream fout;
FileWrite() {
	sc=new Scanner(System.in);
	try {
		fout=new FileOutputStream("/home/administrator/java/copydemo.txt",true);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(IOException e) {
	e.printStackTrace();	
	}
}
public void writeData() {
	String str;
System.out.println("enter howmany data you want to ennter");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		System.out.println("enter data");
		str=sc.next();
		try {
			fout.write(str.getBytes());
			fout.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}		
	}

}

