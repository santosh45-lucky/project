package com.handsoon;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Filesdemo {
	public void create() {
	Path p1=Paths.get("/home/administrator/inputouput/hello7.txt");
	Path p2=Paths.get("/home/administrator/inputouput/hello5.txt");
	try {
		System.out.println("create a new folder"+Files.createDirectories(p1));
		//Files.deleteIfExists(p1);
		System.out.println(Files.readAllLines(p2));

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public void tempdir() {
	Path path=Paths.get("/home/administrator/inputouput");
	//String str="temp";
	try {
	Files.createTempDirectory(path, "santosh");
}catch(IOException e) {
	e.printStackTrace();
}
}
public static void main(String args[]) {
Filesdemo ob=new Filesdemo();
ob.tempdir();
ob.create();
}
}
