package com.day16.niopackage;import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CopyChannelExamle {
public static void main(String args[]) throws IOException {
	try {
		FileInputStream input=new FileInputStream("/home/administrator/inputouput/hello2.txt");
		ReadableByteChannel source=input.getChannel();

		FileOutputStream ouutput=new FileOutputStream("/home/administrator/inputouput/hello5.txt");
		WritableByteChannel dest=ouutput.getChannel();
	
		copyData(source,dest);

		source.close();
		dest.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
private static void copyData(ReadableByteChannel src,WritableByteChannel dest) throws IOException {
	ByteBuffer buffer=ByteBuffer.allocate(16*1024);
	while(src.read(buffer)!=-1) {
		buffer.flip();
	}
	while(buffer.hasRemaining()) {
		dest.write(buffer);
		}
	buffer.clear();
}
}
