package com.day16.niopackage;

import java.nio.file.FileSystem;
import java.nio.file.Path;
import java.nio.file.Paths;

public class niodemo {
public static void main(String args[]) {
	Path path=Paths.get("/home/administrator/inputouput/hello.txt");
	Path path1=Paths.get("new folder");
	FileSystem fs=path.getFileSystem();
	System.out.println(path.isAbsolute());
	System.out.println(path.getNameCount());
	System.out.println(path.toString());
	System.out.println(path.toAbsolutePath());
	System.out.println(path.subpath(1, 3));
	System.out.println(path.getRoot());
	System.out.println(path.getParent());
	System.out.println(path.getFileName());
	System.out.println(fs.toString());
	System.out.print("endding with"+path.endsWith(path1));
	System.out.println("reslove the path"+path.resolve(path1));
	System.out.println("ressolve sibling"+path.resolveSibling(path1));//if we want to add multiple path thhen we 
	
	
}
}
