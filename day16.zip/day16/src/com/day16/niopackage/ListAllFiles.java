package com.day16.niopackage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ListAllFiles {
public static void main(String args[]) throws IOException {
	Path path=Paths.get("/home/administrator/inputouput");
	List<Path> paths=listFiles(path);
	paths.forEach(x-> System.out.println(x));
}
public static List<Path> listFiles(Path path) throws IOException{
	List<Path> result;
	try(Stream<Path> walk=Files.walk(path)){
	result=walk.collect(Collectors.toList());	
	}
	
	return result;
	
}
}
