package com.day16.niopackage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Filesdemo {
public static void main(String arrgs[]) {
	Path p1=Paths.get("/home/administrator/inputouput/hello5.txt");
	try {
		String str="welcome to nio pack";
		Path path1=Files.createFile(p1);
		Files.write(path1, str.getBytes());
	}catch(IOException e) {
		e.printStackTrace();
	}
	Filesdemo ob=new Filesdemo();
	ob.copy();
}
public void copy() {
	Path p1=Paths.get("/home/administrator/inputouput/hello2.txt");
	Path p2=Paths.get("/home/administrator/inputouput/hello4.txt");
	try {
		Files.copy(p1, p2);
		System.out.println("data copy");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
