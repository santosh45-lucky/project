package com.day13.AdvanceThread;

import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class EvanOdd implements Callable<String>{

	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		Thread.sleep(1000);
	return Thread.currentThread().getName();	
	}
public static void main(String args[]) {
	ExecutorService executor=Executors.newFixedThreadPool(5);
	List<String> numlist=new ArrayList<>();
	List<String> oddlist=new ArrayList<>();
	Callable<String> callable=new EvanOdd();
	for(int i=0;i<100;i++) {
		if(i%2==0) {
			Future<String> future=executor.submit(callable);
			try {
				String str=future.get();
			numlist.add("even no"+str+i);
		}catch(Exception e) {
			e.printStackTrace();
		}
		}
	}

for(String fut:numlist) {
	System.out.println(new Date()+":"+fut);
}
}
}