package com.day13.AdvanceThreadcom.futureTask;

import java.util.concurrent.Callable;

public class Mycallable implements Callable<String>{
long waitTime;
Mycallable(int time){
	this.waitTime=time;
}
	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		Thread.sleep(waitTime);
		return Thread.currentThread().getName();
	}

}
