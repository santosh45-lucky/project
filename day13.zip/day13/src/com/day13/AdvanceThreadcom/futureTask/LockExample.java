package com.day13.AdvanceThreadcom.futureTask;

public class LockExample {
public static void main(String args[]) {
	
}
}
