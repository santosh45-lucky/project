package com.day13.AdvanceThreadcom.futureTask;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.ExecutionException;

public class FutureTaskDemo {
public static void main(String args[]) {
	Mycallable callable1=new Mycallable(1000);
	Mycallable callable2=new Mycallable(1000);
	FutureTask<String> task1=new FutureTask<>(callable1);
	FutureTask<String> task2=new FutureTask<>(callable2);
	ExecutorService executor=Executors.newFixedThreadPool(2);
	executor.execute(task1);
	executor.execute(task2);
	while(true){
		try {
		if(task1.isDone()&&task2.isDone()) {
			System.out.println("done");
			executor.shutdown();
			return;
		}
		if(!task1.isDone()) {
			System.out.println("task1 output"+task1.get());
		}
		System.out.println("waitinng for task2to complete");
		String s=task2.get(200L,TimeUnit.MILLISECONDS);
		if(s!=null) {
			System.out.println("future task2 output"+s);
		}
	}catch(InterruptedException|ExecutionException e) {
		e.printStackTrace();
	}catch(TimeoutException e) {
		
	}
	}
}

}
