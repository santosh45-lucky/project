package com.training.project1;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.*;
public class FileInputOutput {
	FileOutputStream output;
	Scanner sc=new Scanner(System.in);

	public void writeData() {
		
		System.out.println("enter hwomany dtata you want to add");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
		System.out.println("enter tthe data");
		String str=sc.next();
		try {
			output=new FileOutputStream("/home/administrator/inputouput/hello.txt",true);
			output.write(str.getBytes());
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException ee) {
			ee.printStackTrace();
		}
	}
	}
	public void readData() {
		
		try {
			FileInputStream finput;
			finput=new FileInputStream("/home/administrator/inputouput/hello.txt");
			
			if(finput.available()==0) {
				System.out.println("no datat aviavle you have to enter data");
				writeData();
			}else {
			byte data[]=new byte[finput.available()];
			finput.read(data);
		for(int i=0;i<data.length;i++) {
			System.out.print((char)data[i]);
		}
			}
	}catch(FileNotFoundException e) {
		System.out.println(e.getMessage());
	}catch(IOException ee) {
		
	}
	}
}
