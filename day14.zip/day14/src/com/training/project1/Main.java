package com.training.project1;

public class Main {
	
public static void main(String args[]) {
	Menu ob=new Menu();
	ob.Menu();
}
}
