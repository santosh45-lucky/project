package com.training.project1;
import java.util.*;
public class Menu {
	Scanner sc=new Scanner(System.in);
	FileInputOutput obj=new FileInputOutput();
public void Menu() {
	String ch="y";
	while(ch.equals("y")) {
	System.out.println("enter your choice");
	System.out.println("1.reading data");
	System.out.println("2.writing data");
	int n=sc.nextInt();
	switch(n) {
	case 1:
		obj.readData();
		break;
	case 2:
		obj.writeData();
		break;
	}
}
	System.out.println("do you want to continue");
	ch=sc.next();
}

}
