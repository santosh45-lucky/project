package com.training.file;

import java.io.File;

public class Retrivefiles {
	public static void disp(File search) {
		System.out.println("name of dicrotory is"+search);
		File farr[]=search.listFiles();
		for(File fobj:farr) {
			if(fobj.isDirectory()) {
				System.out.println("dictory nameis"+fobj.getName());
				disp(fobj);
			}else {
				System.out.println("file name is"+fobj.getName());
			}
		}
	}
public static void main(String args[]) {
	disp(new File("/home/administrator//eclipse-workspace"));
}
}
