package com.training.file;

import java.io.File;
import java.io.IOException;

public class FileDemo {
	File fdir;
	File ffile;
	File ffile1;
public FileDemo() {
	fdir=new File("/home/administrator/eclipse-workspace//filedemo");
	ffile=new File("/home/administrator/eclipse-workspace//filedemo//demo1.txt");
	ffile1=new File("/home/administrator/eclipse-workspace");
	
}
public void  check() {
	System.out.println("is it dicrotory"+fdir.isDirectory());
	System.out.println("file or directory ffor another object"+ffile.isFile());
	System.out.println("parent folder"+fdir.getParentFile());
	boolean result=fdir.mkdir();
	try {
		ffile.createNewFile();
		ffile.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if(result) {
		System.out.println("folder created");
	}else {
		System.out.println("not created");
	}
	String filename[]=fdir.list();
	for(String name:filename) {
		System.out.println("filename"+name);
	}
	
	
	System.out.println("lists of files are");
	File filenames[]=ffile1.listFiles();
	for(File name:filenames) {
		System.out.println(name.getName());
	}
	}
public static void main(String args[]) {
	FileDemo ob=new FileDemo();
	ob.check();
}
}
