package com.training.file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandommAccessfileDemo {
private RandomAccessFile random; 

RandommAccessfileDemo(){
	try {
		random=new RandomAccessFile("/home/administrator//eclipse-workspace","rw");
	}catch(FileNotFoundException e) {
		e.printStackTrace()	;
		}
}
public void readData() {
	try {
		random.seek(0);
		String s=random.readLine();
		System.out.println("string "+s);
		
	}catch(IOException e) {
		e.printStackTrace();
		
	}
	
}
public void writeData() {
	try {
		random.seek(random.length()+1);
		System.out.println("current position of ccursor is"+random.getFilePointer());
		String newstr="this is example of random file";
		random.writeBytes("new data writing inn the file");
		System.out.println("data wriiten in the file");
	}catch(IOException e) {
		e.printStackTrace();
	}
}
public static void main(String args[]){
	RandommAccessfileDemo rdemo=new RandommAccessfileDemo();
	rdemo.readData();
	rdemo.writeData();
	System.out.print("reading data agin");
	rdemo.readData();
}
}
