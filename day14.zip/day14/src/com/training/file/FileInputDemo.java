package com.training.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class FileInputDemo {
FileOutputStream output;

FileInputDemo(){
	
}
public void writeData() {
	try {
		String str="input outpuut example";
		output=new FileOutputStream("/home/administrator/inputouput/hello.txt",true);
		output.write(str.getBytes());
	}catch(FileNotFoundException e) {
		e.printStackTrace();
	}catch(IOException ee) {
		ee.printStackTrace();
	}
}
public void readData() {
	try {
		FileInputStream finput;
		finput=new FileInputStream("/home/administrator/inputouput/hello.txt");
		byte data[]=new byte[finput.available()];
		finput.read(data);
	for(int i=0;i<data.length;i++) {
		System.out.print((char)data[i]);
	}
}catch(FileNotFoundException e) {
	System.out.println(e.getMessage());
}catch(IOException ee) {
	
}
}
public static void main(String args[])
{
	FileInputDemo ob=new FileInputDemo();
	System.out.println("reading data");
	ob.readData();
	ob.writeData();
	ob.readData();
	}
}
